fx_version 'cerulean'
game 'gta5'
author 'Codesign#2715'
description 'Codesign Weather & Time Managment'
version '1.3.6'

shared_scripts {
    'configs/locales.lua',
    'configs/config.lua'
}

client_script 'client/client.lua'

server_scripts {
    'configs/server_customise_me.lua',
    'server/*.lua'
}

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
    'html/font/*.svg',
    'html/font/*.ttf',
    'html/font/*.eot',
    'html/font/*.woff',
    'html/font/*.woff2',
    'html/images/**/*.svg',
    'html/sound/*.ogg'
}

exports {
    'GetWeather'
}

server_exports {
    'GetWeather'
}

provide 'qb-weathersync'
provide 'vSync'

--NO BORRAR ESTAS LINEAS GRACIAS
--Actualizado a la version ESX LEGACY 1.9.0 por JuanjoDev20. Mas info: https://discord.gg/f3cKfFKJpf
--Idioma español añadido por JuanjoDev20. Mas info: https://discord.gg/f3cKfFKJpf